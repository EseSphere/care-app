<!-- jQuery and Bootstrap JS-->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="./js/jquery-3.7.0.min.js"></script>
<!--<script src="./script.js"></script> -->
<script>
    AOS.init();
</script>
</body>

</html>