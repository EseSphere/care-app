<?php require_once('header2.php'); ?>
<script>
    setTimeout(function() {
        window.location.href = "login.php";
    }, 3000); // 5000 milliseconds = 5 seconds
</script>

<div class="container-fluid" id="splash-screen">
    <div id="splash-logo img-logo">
        <img id="geosoft-logo" src="./images/logo.png" alt="Geosoft Care Logo"
            style="width: 200px; height: 70px;">
    </div>
</div>

<a href="./activities.php"></a>
<a href="./allergies.php"></a>
<a href="./care-plan.php"></a>
<a href="./dashboard.php"></a>
<a href="./check-out.php"></a>
<a href="./check-in.php"></a>
<a href="./dnacpr.php"></a>
<a href="./create-pin.php"></a>
<a href="./general-observation.php"></a>
<a href="./index.php"></a>
<a href="./logout.php"></a>
<a href="./log.php"></a>
<a href="./login.php"></a>
<a href="./report-issues.php"></a>
<a href="./task-report.php"></a>
<a href="./signup.php"></a>
<?php require_once('footer2.php'); ?>