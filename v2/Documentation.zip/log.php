<!--This page is to check if carer logs are registered-->
<?php
require_once('header2.php');
header("Location: ./signup.php");
exit();
require_once('footer2.php');
?>